// ----------------------------------------------------------------------
//
// addHerwigParticles.cc
// Author: Lynn Garren
//
// ----------------------------------------------------------------------

#include "HepPDT/defs.h"
#include "HepPDT/TableBuilder.hh"

namespace HepPDT {

bool  addHerwigParticles( std::istream &, TableBuilder & )
{
  return true;
}

}  // namespace HepPDT
